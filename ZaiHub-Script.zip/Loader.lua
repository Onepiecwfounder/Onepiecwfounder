loadstring(game:HttpGet("https://raw.githubusercontent.com/YourGitUsername/ZaiHub/main/Main.lua", true))()
